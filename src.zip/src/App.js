import Top from "./Pages/_Cabeçario";
import { BrowserRouter } from "react-router-dom"
import "./Pages/_Cabeçario/styles.css"

function App() {
  return (
    <BrowserRouter>
    <Top/>
    </BrowserRouter>
      

  );
}

export default App;
